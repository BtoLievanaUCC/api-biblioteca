package com.api.libreria.controllers;

import com.api.libreria.models.ClienteModel;
import com.api.libreria.services.ClienteService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/vista/clientes")
public class ClienteVistaController {

    private final ClienteService clienteService;

    public ClienteVistaController(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping
    public String listarClientes(Model model) {
        model.addAttribute("clientes", clienteService.listarClientes());
        model.addAttribute("cliente", new ClienteModel());
        return "clientes";
    }

    @PostMapping("/guardar")
    public String registrarCliente(@ModelAttribute("cliente") ClienteModel cliente) {
        clienteService.registrarCliente(cliente);
        return "redirect:/vista/clientes";
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable Long id, Model model) {
        ClienteModel cliente = clienteService.obtenerClientePorId(id);
        if (cliente != null) {
            model.addAttribute("cliente", cliente);
            model.addAttribute("clientes", clienteService.listarClientes());
            return "clientes";
        }
        return "redirect:/vista/clientes";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarCliente(@PathVariable Long id) {
        clienteService.eliminarCliente(id);
        return "redirect:/vista/clientes";
    }
}