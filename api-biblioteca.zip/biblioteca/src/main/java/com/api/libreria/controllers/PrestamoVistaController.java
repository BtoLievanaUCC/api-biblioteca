package com.api.libreria.controllers;

import com.api.libreria.models.PrestamoModel;
import com.api.libreria.services.ClienteService;
import com.api.libreria.services.LibroService;
import com.api.libreria.services.PrestamoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/vista/prestamos")
public class PrestamoVistaController {

    private final PrestamoService prestamoService;
    private final ClienteService clienteService;
    private final LibroService libroService;

    public PrestamoVistaController(PrestamoService prestamoService, 
                                   ClienteService clienteService, 
                                   LibroService libroService) {
        this.prestamoService = prestamoService;
        this.clienteService = clienteService;
        this.libroService = libroService;
    }

    @GetMapping
    public String listarPrestamos(Model model) {
        model.addAttribute("prestamos", prestamoService.listarPrestamos());
        model.addAttribute("clientes", clienteService.listarClientes());
        model.addAttribute("libros", libroService.obtenerLibros());
        model.addAttribute("prestamo", new PrestamoModel());
        return "prestamos";
    }

    @PostMapping("/guardar")
    public String registrarPrestamo(@ModelAttribute("prestamo") PrestamoModel prestamo) {
        prestamoService.registrarPrestamo(prestamo);
        return "redirect:/vista/prestamos";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarPrestamo(@PathVariable Long id) {
        prestamoService.eliminarPrestamo(id);
        return "redirect:/vista/prestamos";
    }
}